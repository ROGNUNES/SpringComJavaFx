package br.com.isb.prj;

import org.springframework.stereotype.Service;

@Service
public class Servico1 {
	 
	private String nome;

	
	public Servico1(){
		
		this.nome = "APLICACAO DE CHAMADA";
		System.out.println("dentro do Service do Spring top Demais !!! ");
		System.out.println( this.nome );
	}


	public String getNome() {
		return this.nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
}
