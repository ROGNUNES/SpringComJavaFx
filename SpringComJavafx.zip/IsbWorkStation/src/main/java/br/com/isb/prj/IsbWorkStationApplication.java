package br.com.isb.prj;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import javafx.application.Application;
import javafx.application.HostServices;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import lombok.extern.log4j.Log4j2; 

public class IsbWorkStationApplication extends Application {

	private ConfigurableApplicationContext context;
	
	@Autowired
	private Servico1 servico1;


	@Override
	public void init() throws Exception {
		ApplicationContextInitializer<GenericApplicationContext> initializer = ac -> {
			ac.registerBean(Application.class, () -> this);
			ac.registerBean(Parameters.class, this::getParameters);
			ac.registerBean(HostServices.class, this::getHostServices);

		};
		
		

		this.context = new SpringApplicationBuilder().sources(JavaFxWorkStationApplication.class)
				.initializers(initializer).run(getParameters().getRaw().toArray(new String[0]));

	System.out.println("JA utilizando o AUtoWired ==> "+ this.servico1.getNome() );

	}

	@Override
	public void start( Stage primaryStage ) throws Exception {
		
			this.context.publishEvent( new StageReadyEvent( primaryStage ));
	}

	@Override
	public void stop() throws Exception{
		
		this.context.close();
		Platform.exit();
		
		
	}
	
}

class StageReadyEvent extends ApplicationEvent {

	private final Stage stage;

	StageReadyEvent(Stage stage) {
		super(stage);
		this.stage = stage;
	}

	public Stage getStage() {
		return stage;
	}
}

@Log4j2
@Component
class StageInitializer implements ApplicationListener<StageReadyEvent> {

	private final String applicationTitle;
	private final ApplicationContext applicationContext;

	StageInitializer( @Value("${spring.application.name}") String applicationTitle,	
																		ApplicationContext applicationContext) {
		this.applicationTitle = applicationTitle;
		this.applicationContext = applicationContext;
	}

	@Override
	public void onApplicationEvent(StageReadyEvent stageReadyEvent) {
		try {
			Stage stage = stageReadyEvent.getStage();
			ClassPathResource fxml = new ClassPathResource("/Cena1.fxml");
			FXMLLoader fxmlLoader = new FXMLLoader(fxml.getURL());
			fxmlLoader.setControllerFactory( this.applicationContext::getBean );
			Parent root = fxmlLoader.load();
			Scene scene = new Scene(root, 800, 600);
			stage.setScene(scene); // Criando a Cena principal 
			stage.setTitle(this.applicationTitle);
			stage.setMaximized(true);
			stage.show();
		}
		catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}