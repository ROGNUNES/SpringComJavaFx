package br.com.isb.prj;

import javafx.fxml.FXML;
import javafx.scene.control.Button;


public class UiController {
	
  @FXML	
  private Button btn1;
  
  
   public void aa(){
	  
	  System.out.println( "nome do botão -> " + this.btn1.getText() );
	  this.btn1.setText("rognunes");
	  
	  
  }
  
  @FXML
	 void initialize() {
	 }
  

}
