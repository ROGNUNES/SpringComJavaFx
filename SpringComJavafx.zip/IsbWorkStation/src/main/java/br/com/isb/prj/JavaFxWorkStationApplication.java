package br.com.isb.prj;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javafx.application.Application;

@SpringBootApplication
public class JavaFxWorkStationApplication {
	
	
	public static void main(String[] args) {
		//
		Application.launch(IsbWorkStationApplication.class, args );
		//
	}

}
